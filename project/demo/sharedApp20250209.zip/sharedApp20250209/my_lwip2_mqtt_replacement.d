../my_lwip2_mqtt_replacement.o: ../my_lwip2_mqtt_replacement.c \
 ../../../../include/xr_config.h ../../../../include/generated/autoconf.h \
 ../../../../project/common/prj_conf_opt.h \
 ../../../../project/demo/sharedApp/prj_config.h \
 ../my_lwip2_mqtt_replacement.h ../my_lwip2_mqtt_opts.h \
 ../../../../include/net/lwip-2.1.2/lwip/opt.h \
 ../../../../include/net/lwip-2.1.2/lwipopts.h \
 ../../../../include/net/lwip-2.1.2/lwip/debug.h \
 ../../../../include/net/lwip-2.1.2/lwip/arch.h \
 ../../../../include/net/lwip-2.1.2/arch/cc.h \
 ../../../../include/sys/defs.h ../../../../include/types.h \
 ../../../../include/compiler.h ../../../../include/libc/errno.h \
 ../../../../include/kernel/os/os_errno.h \
 ../../../../include/kernel/os/os_common.h \
 ../../../../include/libc/sys/time.h ../../../../include/libc/stdio.h \
 ../../../../include/kernel/os/os_time.h ../../../../include/sys/endian.h \
 ../../../../include/net/lwip-2.1.2/lwip/err.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/def.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip4_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip6_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/def.h \
 ../../../../include/net/lwip-2.1.2/lwip/sockets.h \
 ../../../../include/net/lwip-2.1.2/lwip/netif.h \
 ../../../../include/net/lwip-2.1.2/lwip/pbuf.h \
 ../../../../include/net/lwip-2.1.2/lwip/stats.h \
 ../../../../include/net/lwip-2.1.2/lwip/mem.h \
 ../../../../include/net/lwip-2.1.2/lwip/memp.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/memp_std.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/memp_priv.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/mem_priv.h \
 ../../../../include/net/lwip-2.1.2/lwip/inet.h \
 ../../../../include/net/lwip-2.1.2/lwip/errno.h \
 ../../../../include/net/lwip-2.1.2/lwip/tcp.h \
 ../../../../include/net/lwip-2.1.2/lwip/tcpbase.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip4.h \
 ../../../../include/net/lwip-2.1.2/lwip/prot/ip4.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip6.h \
 ../../../../include/net/lwip-2.1.2/lwip/prot/ip.h \
 ../../../../include/net/lwip-2.1.2/lwip/icmp.h \
 ../../../../include/net/lwip-2.1.2/lwip/prot/icmp.h

../../../../include/xr_config.h:

../../../../include/generated/autoconf.h:

../../../../project/common/prj_conf_opt.h:

../../../../project/demo/sharedApp/prj_config.h:

../my_lwip2_mqtt_replacement.h:

../my_lwip2_mqtt_opts.h:

../../../../include/net/lwip-2.1.2/lwip/opt.h:

../../../../include/net/lwip-2.1.2/lwipopts.h:

../../../../include/net/lwip-2.1.2/lwip/debug.h:

../../../../include/net/lwip-2.1.2/lwip/arch.h:

../../../../include/net/lwip-2.1.2/arch/cc.h:

../../../../include/sys/defs.h:

../../../../include/types.h:

../../../../include/compiler.h:

../../../../include/libc/errno.h:

../../../../include/kernel/os/os_errno.h:

../../../../include/kernel/os/os_common.h:

../../../../include/libc/sys/time.h:

../../../../include/libc/stdio.h:

../../../../include/kernel/os/os_time.h:

../../../../include/sys/endian.h:

../../../../include/net/lwip-2.1.2/lwip/err.h:

../../../../include/net/lwip-2.1.2/lwip/ip_addr.h:

../../../../include/net/lwip-2.1.2/lwip/def.h:

../../../../include/net/lwip-2.1.2/lwip/ip4_addr.h:

../../../../include/net/lwip-2.1.2/lwip/ip6_addr.h:

../../../../include/net/lwip-2.1.2/lwip/def.h:

../../../../include/net/lwip-2.1.2/lwip/sockets.h:

../../../../include/net/lwip-2.1.2/lwip/netif.h:

../../../../include/net/lwip-2.1.2/lwip/pbuf.h:

../../../../include/net/lwip-2.1.2/lwip/stats.h:

../../../../include/net/lwip-2.1.2/lwip/mem.h:

../../../../include/net/lwip-2.1.2/lwip/memp.h:

../../../../include/net/lwip-2.1.2/lwip/priv/memp_std.h:

../../../../include/net/lwip-2.1.2/lwip/priv/memp_priv.h:

../../../../include/net/lwip-2.1.2/lwip/priv/mem_priv.h:

../../../../include/net/lwip-2.1.2/lwip/inet.h:

../../../../include/net/lwip-2.1.2/lwip/errno.h:

../../../../include/net/lwip-2.1.2/lwip/tcp.h:

../../../../include/net/lwip-2.1.2/lwip/tcpbase.h:

../../../../include/net/lwip-2.1.2/lwip/ip.h:

../../../../include/net/lwip-2.1.2/lwip/ip4.h:

../../../../include/net/lwip-2.1.2/lwip/prot/ip4.h:

../../../../include/net/lwip-2.1.2/lwip/ip6.h:

../../../../include/net/lwip-2.1.2/lwip/prot/ip.h:

../../../../include/net/lwip-2.1.2/lwip/icmp.h:

../../../../include/net/lwip-2.1.2/lwip/prot/icmp.h:
