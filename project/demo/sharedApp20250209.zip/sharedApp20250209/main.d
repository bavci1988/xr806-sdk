../main.o: ../main.c ../../../../include/xr_config.h \
 ../../../../include/generated/autoconf.h \
 ../../../../project/common/prj_conf_opt.h \
 ../../../../project/demo/sharedApp/prj_config.h \
 ../../../../include/libc/stdio.h \
 ../../../../project/common/framework/platform_init.h \
 ../../../../project/common/framework/sysinfo.h \
 ../../../../include/net/lwip-2.1.2/lwip/netif.h \
 ../../../../include/net/lwip-2.1.2/lwip/opt.h \
 ../../../../include/net/lwip-2.1.2/lwipopts.h \
 ../../../../include/net/lwip-2.1.2/lwip/debug.h \
 ../../../../include/net/lwip-2.1.2/lwip/arch.h \
 ../../../../include/net/lwip-2.1.2/arch/cc.h \
 ../../../../include/sys/defs.h ../../../../include/types.h \
 ../../../../include/compiler.h ../../../../include/libc/errno.h \
 ../../../../include/kernel/os/os_errno.h \
 ../../../../include/kernel/os/os_common.h \
 ../../../../include/libc/sys/time.h \
 ../../../../include/kernel/os/os_time.h ../../../../include/sys/endian.h \
 ../../../../include/net/lwip-2.1.2/lwip/err.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/def.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip4_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/ip6_addr.h \
 ../../../../include/net/lwip-2.1.2/lwip/def.h \
 ../../../../include/net/lwip-2.1.2/lwip/pbuf.h \
 ../../../../include/net/lwip-2.1.2/lwip/stats.h \
 ../../../../include/net/lwip-2.1.2/lwip/mem.h \
 ../../../../include/net/lwip-2.1.2/lwip/memp.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/memp_std.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/memp_priv.h \
 ../../../../include/net/lwip-2.1.2/lwip/priv/mem_priv.h \
 ../../../../include/net/wlan/wlan.h \
 ../../../../include/net/wlan/wlan_defs.h \
 ../../../../include/net/wlan/wlan_common.h \
 ../../../../include/net/ethernetif/ethernetif.h \
 ../../../../project/common/framework/net_ctrl.h \
 ../../../../include/net/wlan/wlan_ext_req.h \
 ../../../../project/common/framework/sys_ctrl/sys_ctrl.h \
 ../../../../project/common/framework/sys_ctrl/event_queue.h \
 ../../../../project/common/framework/sys_ctrl/publisher.h \
 ../../../../include/sys/list.h ../../../../include/kernel/os/os.h \
 ../../../../include/kernel/os/os_thread.h \
 ../../../../include/kernel/os/os_queue.h \
 ../../../../include/kernel/os/os_semaphore.h \
 ../../../../include/kernel/os/os_mutex.h \
 ../../../../include/kernel/os/os_timer.h \
 ../../../../project/common/framework/sys_ctrl/observer.h \
 ../../../../project/common/framework/sys_ctrl/looper.h ../serial.h \
 ../../../../include/driver/chip/hal_uart.h \
 ../../../../include/driver/chip/hal_def.h \
 ../../../../include/driver/chip/chip.h \
 ../../../../include/driver/cmsis/core_cm33.h \
 ../../../../include/driver/cmsis/cmsis_version.h \
 ../../../../include/driver/cmsis/cmsis_compiler.h \
 ../../../../include/driver/cmsis/cmsis_gcc.h \
 ../../../../include/driver/chip/hal_dma.h ../shared/src/new_cfg.h \
 ../shared/src/new_common.h ../shared/src/obk_config.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/FreeRTOS.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/FreeRTOSConfig.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/projdefs.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/portable.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/deprecated_definitions.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/portable/GCC/ARM_CM33_NTZ/non_secure/portmacro.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/mpu_wrappers.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/semphr.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/queue.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/task.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/list.h \
 ../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/task.h \
 ../../../../include/net/lwip-2.1.2/lwip/sockets.h \
 ../../../../include/net/lwip-2.1.2/lwip/inet.h \
 ../../../../include/net/lwip-2.1.2/lwip/errno.h ../shared/src/new_pins.h \
 ../shared/src/hal/hal_wifi.h ../shared/src/mqtt/new_mqtt.h \
 ../shared/src/mqtt/../obk_config.h ../shared/src/mqtt/../new_common.h \
 ../../../../include/net/lwip-2.1.2/lwip/netdb.h \
 ../../../../project/demo/sharedApp/my_lwip2_mqtt_replacement.h \
 ../../../../project/demo/sharedApp/my_lwip2_mqtt_opts.h \
 ../shared/src/mqtt/new_mqtt_deduper.h ../shared/src/new_common.h

../../../../include/xr_config.h:

../../../../include/generated/autoconf.h:

../../../../project/common/prj_conf_opt.h:

../../../../project/demo/sharedApp/prj_config.h:

../../../../include/libc/stdio.h:

../../../../project/common/framework/platform_init.h:

../../../../project/common/framework/sysinfo.h:

../../../../include/net/lwip-2.1.2/lwip/netif.h:

../../../../include/net/lwip-2.1.2/lwip/opt.h:

../../../../include/net/lwip-2.1.2/lwipopts.h:

../../../../include/net/lwip-2.1.2/lwip/debug.h:

../../../../include/net/lwip-2.1.2/lwip/arch.h:

../../../../include/net/lwip-2.1.2/arch/cc.h:

../../../../include/sys/defs.h:

../../../../include/types.h:

../../../../include/compiler.h:

../../../../include/libc/errno.h:

../../../../include/kernel/os/os_errno.h:

../../../../include/kernel/os/os_common.h:

../../../../include/libc/sys/time.h:

../../../../include/kernel/os/os_time.h:

../../../../include/sys/endian.h:

../../../../include/net/lwip-2.1.2/lwip/err.h:

../../../../include/net/lwip-2.1.2/lwip/ip_addr.h:

../../../../include/net/lwip-2.1.2/lwip/def.h:

../../../../include/net/lwip-2.1.2/lwip/ip4_addr.h:

../../../../include/net/lwip-2.1.2/lwip/ip6_addr.h:

../../../../include/net/lwip-2.1.2/lwip/def.h:

../../../../include/net/lwip-2.1.2/lwip/pbuf.h:

../../../../include/net/lwip-2.1.2/lwip/stats.h:

../../../../include/net/lwip-2.1.2/lwip/mem.h:

../../../../include/net/lwip-2.1.2/lwip/memp.h:

../../../../include/net/lwip-2.1.2/lwip/priv/memp_std.h:

../../../../include/net/lwip-2.1.2/lwip/priv/memp_priv.h:

../../../../include/net/lwip-2.1.2/lwip/priv/mem_priv.h:

../../../../include/net/wlan/wlan.h:

../../../../include/net/wlan/wlan_defs.h:

../../../../include/net/wlan/wlan_common.h:

../../../../include/net/ethernetif/ethernetif.h:

../../../../project/common/framework/net_ctrl.h:

../../../../include/net/wlan/wlan_ext_req.h:

../../../../project/common/framework/sys_ctrl/sys_ctrl.h:

../../../../project/common/framework/sys_ctrl/event_queue.h:

../../../../project/common/framework/sys_ctrl/publisher.h:

../../../../include/sys/list.h:

../../../../include/kernel/os/os.h:

../../../../include/kernel/os/os_thread.h:

../../../../include/kernel/os/os_queue.h:

../../../../include/kernel/os/os_semaphore.h:

../../../../include/kernel/os/os_mutex.h:

../../../../include/kernel/os/os_timer.h:

../../../../project/common/framework/sys_ctrl/observer.h:

../../../../project/common/framework/sys_ctrl/looper.h:

../serial.h:

../../../../include/driver/chip/hal_uart.h:

../../../../include/driver/chip/hal_def.h:

../../../../include/driver/chip/chip.h:

../../../../include/driver/cmsis/core_cm33.h:

../../../../include/driver/cmsis/cmsis_version.h:

../../../../include/driver/cmsis/cmsis_compiler.h:

../../../../include/driver/cmsis/cmsis_gcc.h:

../../../../include/driver/chip/hal_dma.h:

../shared/src/new_cfg.h:

../shared/src/new_common.h:

../shared/src/obk_config.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/FreeRTOS.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/FreeRTOSConfig.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/projdefs.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/portable.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/deprecated_definitions.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/portable/GCC/ARM_CM33_NTZ/non_secure/portmacro.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/mpu_wrappers.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/semphr.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/queue.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/task.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/list.h:

../../../../include/kernel/FreeRTOS/FreeRTOSv10.2.1/task.h:

../../../../include/net/lwip-2.1.2/lwip/sockets.h:

../../../../include/net/lwip-2.1.2/lwip/inet.h:

../../../../include/net/lwip-2.1.2/lwip/errno.h:

../shared/src/new_pins.h:

../shared/src/hal/hal_wifi.h:

../shared/src/mqtt/new_mqtt.h:

../shared/src/mqtt/../obk_config.h:

../shared/src/mqtt/../new_common.h:

../../../../include/net/lwip-2.1.2/lwip/netdb.h:

../../../../project/demo/sharedApp/my_lwip2_mqtt_replacement.h:

../../../../project/demo/sharedApp/my_lwip2_mqtt_opts.h:

../shared/src/mqtt/new_mqtt_deduper.h:

../shared/src/new_common.h:
