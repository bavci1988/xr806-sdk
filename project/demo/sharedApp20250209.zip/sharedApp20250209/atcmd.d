../atcmd.o: ../atcmd.c ../../../project/common/prj_conf_opt.h \
 ../../../project/oxr_hello/prj_config.h

../../../project/common/prj_conf_opt.h:

../../../project/oxr_hello/prj_config.h:
