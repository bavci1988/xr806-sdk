../serial.o: ../serial.c ../../../../include/xr_config.h \
 ../../../../include/generated/autoconf.h \
 ../../../../project/common/prj_conf_opt.h \
 ../../../../project/demo/sharedApp/prj_config.h \
 ../../../../include/kernel/os/os.h \
 ../../../../include/kernel/os/os_time.h \
 ../../../../include/kernel/os/os_common.h ../../../../include/compiler.h \
 ../../../../include/kernel/os/os_thread.h \
 ../../../../include/kernel/os/os_queue.h \
 ../../../../include/kernel/os/os_semaphore.h \
 ../../../../include/kernel/os/os_mutex.h \
 ../../../../include/kernel/os/os_timer.h ../serial.h \
 ../../../../include/driver/chip/hal_uart.h \
 ../../../../include/driver/chip/hal_def.h \
 ../../../../include/driver/chip/chip.h \
 ../../../../include/driver/cmsis/core_cm33.h \
 ../../../../include/driver/cmsis/cmsis_version.h \
 ../../../../include/driver/cmsis/cmsis_compiler.h \
 ../../../../include/driver/cmsis/cmsis_gcc.h \
 ../../../../include/driver/chip/hal_dma.h ../serial_debug.h \
 ../../../../include/libc/stdio.h ../../../../include/sys/xr_util.h \
 ../../../../include/sys/interrupt.h

../../../../include/xr_config.h:

../../../../include/generated/autoconf.h:

../../../../project/common/prj_conf_opt.h:

../../../../project/demo/sharedApp/prj_config.h:

../../../../include/kernel/os/os.h:

../../../../include/kernel/os/os_time.h:

../../../../include/kernel/os/os_common.h:

../../../../include/compiler.h:

../../../../include/kernel/os/os_thread.h:

../../../../include/kernel/os/os_queue.h:

../../../../include/kernel/os/os_semaphore.h:

../../../../include/kernel/os/os_mutex.h:

../../../../include/kernel/os/os_timer.h:

../serial.h:

../../../../include/driver/chip/hal_uart.h:

../../../../include/driver/chip/hal_def.h:

../../../../include/driver/chip/chip.h:

../../../../include/driver/cmsis/core_cm33.h:

../../../../include/driver/cmsis/cmsis_version.h:

../../../../include/driver/cmsis/cmsis_compiler.h:

../../../../include/driver/cmsis/cmsis_gcc.h:

../../../../include/driver/chip/hal_dma.h:

../serial_debug.h:

../../../../include/libc/stdio.h:

../../../../include/sys/xr_util.h:

../../../../include/sys/interrupt.h:
